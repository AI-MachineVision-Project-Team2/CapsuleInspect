﻿using CapsuleInspect.Algorithm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapsuleInspect.Core;

namespace CapsuleInspect.Teach
{
    public class InspWindowFactory
    {
        #region Singleton Instance
        private static readonly Lazy<InspWindowFactory> _instance = new Lazy<InspWindowFactory>(() => new InspWindowFactory());

        public static InspWindowFactory Inst
        {
            get
            {
                return _instance.Value;
            }
        }
        #endregion

        //같은 타입의 일련번호 관리를 위한 딕셔너리
        private Dictionary<string, int> _windowTypeNo = new Dictionary<string, int>();

        public InspWindowFactory() { }

        //InspWindow를 생성하기 위해, 타입을 입력받아, 생성된 InspWindow 반환
        public InspWindow Create(InspWindowType windowType, bool addAlgorithm = true)
        {
            string name, prefix;
            if (!GetWindowName(windowType, out name, out prefix))
                return null;

            InspWindow inspWindow = new InspWindow(windowType, name);
            if (inspWindow is null)
                return null;

            if (!_windowTypeNo.ContainsKey(name))
                _windowTypeNo[name] = 0;

            int curID = _windowTypeNo[name];
            curID++;

            inspWindow.UID = string.Format("{0}_{1:D6}", prefix, curID);

            _windowTypeNo[name] = curID;

            if (addAlgorithm)
                AddInspAlgorithm(inspWindow);

            return inspWindow;
        }

        private bool AddInspAlgorithm(InspWindow inspWindow)
        {
            switch (inspWindow.InspWindowType)
            {
                case InspWindowType.Crack:
                    inspWindow.AddInspAlgorithm(InspectType.InspFilter);
                    inspWindow.AddInspAlgorithm(InspectType.InspAI);
                    inspWindow.AddInspAlgorithm(InspectType.InspBinary);
                    inspWindow.AddInspAlgorithm(InspectType.InspMatch);
                    break;
                case InspWindowType.Scratch:
                    inspWindow.AddInspAlgorithm(InspectType.InspFilter);
                    inspWindow.AddInspAlgorithm(InspectType.InspAI);
                    inspWindow.AddInspAlgorithm(InspectType.InspBinary);
                    inspWindow.AddInspAlgorithm(InspectType.InspMatch);
                    break;
                case InspWindowType.Squeeze:
                    inspWindow.AddInspAlgorithm(InspectType.InspFilter);
                    inspWindow.AddInspAlgorithm(InspectType.InspAI);
                    inspWindow.AddInspAlgorithm(InspectType.InspBinary);
                    inspWindow.AddInspAlgorithm(InspectType.InspMatch);
                    break;
                case InspWindowType.PrintDefect:
                    inspWindow.AddInspAlgorithm(InspectType.InspFilter);
                    inspWindow.AddInspAlgorithm(InspectType.InspAI);
                    inspWindow.AddInspAlgorithm(InspectType.InspBinary);
                    inspWindow.AddInspAlgorithm(InspectType.InspMatch);
                    break;
                case InspWindowType.ID:
                    inspWindow.AddInspAlgorithm(InspectType.InspMatch);
                    break;
            }

            return true;
        }

        //타입을 입력하면, 해당 타입의 이름과 UID 이름 반환
        private bool GetWindowName(InspWindowType windowType, out string name, out string prefix)
        {
            name = string.Empty;
            prefix = string.Empty;
            switch (windowType)
            {
                case InspWindowType.Crack:
                    name = "Crack";
                    prefix = "Crack";
                    break;
                case InspWindowType.Scratch:
                    name = "Scratch";
                    prefix = "Scratch";
                    break;
                case InspWindowType.Squeeze:
                    name = "Squeeze";
                    prefix = "Squeeze";
                    break;
                case InspWindowType.PrintDefect:
                    name = "PrintDefect";
                    prefix = "PrintDefect";
                    break;
                case InspWindowType.ID:
                    name = "ID";
                    prefix = "ID";
                    break;
                default:
                    return false;
            }
            return true;
        }

    }
}
